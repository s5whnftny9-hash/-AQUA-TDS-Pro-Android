# AQUA TDS Pro

GitHub-ready web source for Android APK packaging.

- Entry file: `index.html`
- Offline single-file app
- Mobile viewport includes `viewport-fit=cover`

Upload the contents of this folder to the root of your GitHub repository.
