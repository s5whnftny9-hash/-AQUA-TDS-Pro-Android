AQUA TDS Pro — ساخت APK فقط با iPhone و Safari

این نسخه از پروژه برای GitHub Actions آماده شده است.
برای ساخت APK نیازی به Mac یا Android Studio ندارید.

=========================================================
روش پیشنهادی روی iPhone
=========================================================

1) وارد github.com شوید و Sign in کنید.

2) یک Repository جدید بسازید.
   پیشنهاد نام:
   AQUA-TDS-Pro-Android

3) این ZIP را در برنامه Files آیفون Extract کنید.

4) محتویات داخل پوشه AQUA_TDS_Pro_Android_GitHub را داخل Repository آپلود کنید.
   مهم:
   خود پوشه را به عنوان یک فایل ZIP داخل Repository نگذارید.
   باید فایل‌های build.gradle، settings.gradle، پوشه app و پوشه .github
   در Root همان Repository باشند.

5) بعد از Upload/Commit به تب Actions بروید.

6) Workflow با نام:
   Build AQUA TDS Pro APK
   را باز کنید.

7) دکمه Run workflow را بزنید و دوباره Run workflow را تأیید کنید.

8) چند دقیقه بعد، وقتی Build سبز شد، وارد همان Run شوید.

9) پایین صفحه بخش Artifacts را پیدا کنید.

10) روی:
    AQUA-TDS-Pro-APK
    بزنید.

11) GitHub یک ZIP کوچک دانلود می‌کند.
    آن را در Files باز و Extract کنید.

12) داخل آن فایل زیر قرار دارد:
    AQUA-TDS-Pro.apk

=========================================================
مشخصات پروژه
=========================================================

App name:
AQUA TDS Pro

Package:
com.aquatdspro.app

Native background:
#010510

HTML:
app/src/main/assets/index.html

فایل HTML اصلی بدون تغییر محتوایی داخل پروژه قرار دارد.

Logo:
لوگوی AQUA TDS Pro ساخته‌شده در همین گفتگو به عنوان Launcher Icon استفاده شده است.

=========================================================
نکته مهم
=========================================================

فایل APK روی iPhone نصب نمی‌شود.
بعد از ساخته‌شدن، APK را برای گوشی Android ارسال کنید و آنجا نصب کنید.

در Android ممکن است برای نصب فایل خارج از Play Store لازم باشد
Allow from this source / Install unknown apps را برای Files یا مرورگر فعال کنید.
