AQUA TDS Pro — Android Wrapper

این پروژه برای اجرای فایل HTML اصلی AQUA TDS Pro به صورت برنامه Android ساخته شده است.

مشخصات:
- نام برنامه: AQUA TDS Pro
- Package: com.aquatdspro.app
- Background Native: #010510
- فایل اصلی HTML: app/src/main/assets/index.html
- فایل HTML دقیقاً از فایل ارسالی «test» کپی شده و محتوای آن تغییر داده نشده است.
- JavaScript و LocalStorage فعال هستند.
- WebView به صورت Hardware Accelerated اجرا می‌شود.
- آیکون برنامه از لوگوی نهایی AQUA TDS Pro ساخته شده است.
- برنامه برای اجرای فایل HTML به اینترنت نیاز ندارد.

ساخت APK در Android Studio:
1) پوشه پروژه را در Android Studio باز کنید.
2) اجازه دهید Gradle Sync کامل شود.
3) از منوی Build گزینه Build APK(s) را انتخاب کنید.
4) فایل Debug APK در مسیر زیر ساخته می‌شود:
   app/build/outputs/apk/debug/app-debug.apk

برای APK نهایی امضاشده:
Build > Generate Signed App Bundle / APK > APK

نکته:
این محیط Android SDK/Gradle کامل برای کامپایل APK ندارد، بنابراین این فایل ZIP پروژه آماده Android Studio است.
